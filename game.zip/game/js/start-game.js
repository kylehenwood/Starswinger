// start a game
function startGame() {
  gameState = "playGame";
  gravity = 0;

  // clearVariables();
  // gameSetup();

  changeHook(0);
  //setTimeout(function(){
  //},480);
}
